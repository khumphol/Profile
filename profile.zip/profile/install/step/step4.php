  <center><div class="step_active">1</div><div class="step_detail_active"><?php echo @LA_IS_ABOUT_SYSTEM;?></div><div class="step_active">2</div><div class="step_detail_active"><?php echo @LA_IS_DATABASE;?></div><div class="step_active">3</div><div class="step_detail_active"><?php echo @LA_IS_ADMINISTRATOR;?></div><div class="step_active">4</div></center>
<center>
  <h2><?php echo @LA_IS_DONE_1;?></h2>
  <h2><?php echo @LA_IS_DONE_2;?> <img src="../media/logo/logo.png" width="80" alt=""/></h2>
  <h2><?php echo @LA_IS_DONE_3;?></h2>
  </center>