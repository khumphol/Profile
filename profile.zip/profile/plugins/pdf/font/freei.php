<?php
$type='Type1';
$name='FreesiaUPCItalic';
$desc=array('Ascent'=>456,'Descent'=>-131,'CapHeight'=>449,'Flags'=>96,'FontBBox'=>'[-352 -245 797 838]','ItalicAngle'=>-10,'StemV'=>70);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>600,chr(1)=>600,chr(2)=>600,chr(3)=>600,chr(4)=>600,chr(5)=>600,chr(6)=>600,chr(7)=>600,chr(8)=>600,chr(9)=>600,chr(10)=>600,chr(11)=>600,chr(12)=>600,chr(13)=>600,chr(14)=>600,chr(15)=>600,chr(16)=>600,chr(17)=>600,chr(18)=>600,chr(19)=>600,chr(20)=>600,chr(21)=>600,
	chr(22)=>600,chr(23)=>600,chr(24)=>600,chr(25)=>600,chr(26)=>600,chr(27)=>600,chr(28)=>600,chr(29)=>600,chr(30)=>600,chr(31)=>600,' '=>222,'!'=>222,'"'=>248,'#'=>440,'$'=>390,'%'=>589,'&'=>412,'\''=>190,'('=>318,')'=>318,'*'=>327,'+'=>401,
	','=>202,'-'=>401,'.'=>173,'/'=>350,'0'=>440,'1'=>440,'2'=>440,'3'=>440,'4'=>440,'5'=>440,'6'=>440,'7'=>440,'8'=>440,'9'=>440,':'=>225,';'=>202,'<'=>320,'='=>401,'>'=>313,'?'=>400,'@'=>524,'A'=>367,
	'B'=>407,'C'=>407,'D'=>433,'E'=>367,'F'=>314,'G'=>433,'H'=>433,'I'=>171,'J'=>262,'K'=>407,'L'=>328,'M'=>538,'N'=>433,'O'=>433,'P'=>367,'Q'=>433,'R'=>407,'S'=>407,'T'=>328,'U'=>419,'V'=>367,'W'=>538,
	'X'=>354,'Y'=>367,'Z'=>354,'['=>197,'\\'=>341,']'=>197,'^'=>393,'_'=>328,'`'=>249,'a'=>354,'b'=>354,'c'=>314,'d'=>354,'e'=>354,'f'=>197,'g'=>328,'h'=>354,'i'=>157,'j'=>145,'k'=>328,'l'=>157,'m'=>538,
	'n'=>354,'o'=>354,'p'=>354,'q'=>354,'r'=>210,'s'=>341,'t'=>210,'u'=>354,'v'=>288,'w'=>433,'x'=>288,'y'=>276,'z'=>276,'{'=>197,'|'=>171,'}'=>197,'~'=>393,chr(127)=>600,chr(128)=>600,chr(129)=>600,chr(130)=>600,chr(131)=>600,
	chr(132)=>600,chr(133)=>600,chr(134)=>600,chr(135)=>600,chr(136)=>600,chr(137)=>600,chr(138)=>600,chr(139)=>600,chr(140)=>600,chr(141)=>600,chr(142)=>600,chr(143)=>600,chr(144)=>600,chr(145)=>600,chr(146)=>600,chr(147)=>600,chr(148)=>600,chr(149)=>600,chr(150)=>600,chr(151)=>600,chr(152)=>600,chr(153)=>600,
	chr(154)=>600,chr(155)=>600,chr(156)=>600,chr(157)=>600,chr(158)=>600,chr(159)=>600,chr(160)=>222,chr(161)=>412,chr(162)=>363,chr(163)=>370,chr(164)=>429,chr(165)=>433,chr(166)=>467,chr(167)=>311,chr(168)=>366,chr(169)=>429,chr(170)=>389,chr(171)=>397,chr(172)=>546,chr(173)=>554,chr(174)=>464,chr(175)=>465,
	chr(176)=>381,chr(177)=>472,chr(178)=>585,chr(179)=>572,chr(180)=>430,chr(181)=>430,chr(182)=>406,chr(183)=>455,chr(184)=>406,chr(185)=>462,chr(186)=>451,chr(187)=>451,chr(188)=>404,chr(189)=>405,chr(190)=>470,chr(191)=>471,chr(192)=>455,chr(193)=>446,chr(194)=>396,chr(195)=>347,chr(196)=>406,chr(197)=>409,
	chr(198)=>454,chr(199)=>338,chr(200)=>429,chr(201)=>478,chr(202)=>406,chr(203)=>455,chr(204)=>462,chr(205)=>401,chr(206)=>401,chr(207)=>389,chr(208)=>338,chr(209)=>0,chr(210)=>347,chr(211)=>329,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>600,
	chr(220)=>600,chr(221)=>600,chr(222)=>600,chr(223)=>372,chr(224)=>226,chr(225)=>388,chr(226)=>254,chr(227)=>272,chr(228)=>277,chr(229)=>326,chr(230)=>452,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>516,chr(240)=>432,chr(241)=>442,
	chr(242)=>454,chr(243)=>431,chr(244)=>478,chr(245)=>483,chr(246)=>442,chr(247)=>496,chr(248)=>470,chr(249)=>487,chr(250)=>431,chr(251)=>801,chr(252)=>600,chr(253)=>600,chr(254)=>600,chr(255)=>600);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='freei.z';
$size1=5677;
$size2=30634;
?>
