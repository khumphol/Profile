<?php
$type='Type1';
$name='PLETomWide';
$desc=array('Ascent'=>471,'Descent'=>-129,'CapHeight'=>286,'Flags'=>32,'FontBBox'=>'[-612 -269 930 567]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>500);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>500,chr(1)=>500,chr(2)=>500,chr(3)=>500,chr(4)=>500,chr(5)=>500,chr(6)=>500,chr(7)=>500,chr(8)=>500,chr(9)=>500,chr(10)=>500,chr(11)=>500,chr(12)=>500,chr(13)=>500,chr(14)=>500,chr(15)=>500,chr(16)=>500,chr(17)=>500,chr(18)=>500,chr(19)=>500,chr(20)=>500,chr(21)=>500,
	chr(22)=>500,chr(23)=>500,chr(24)=>500,chr(25)=>500,chr(26)=>500,chr(27)=>500,chr(28)=>500,chr(29)=>500,chr(30)=>500,chr(31)=>500,' '=>266,'!'=>235,'"'=>202,'#'=>529,'$'=>443,'%'=>353,'&'=>430,'\''=>143,'('=>235,')'=>265,'*'=>424,'+'=>354,
	','=>162,'-'=>461,'.'=>178,'/'=>447,'0'=>451,'1'=>199,'2'=>437,'3'=>445,'4'=>357,'5'=>438,'6'=>346,'7'=>375,'8'=>331,'9'=>417,':'=>222,';'=>195,'<'=>336,'='=>576,'>'=>341,'?'=>368,'@'=>478,'A'=>523,
	'B'=>600,'C'=>624,'D'=>736,'E'=>497,'F'=>431,'G'=>733,'H'=>453,'I'=>542,'J'=>622,'K'=>438,'L'=>669,'M'=>468,'N'=>591,'O'=>640,'P'=>541,'Q'=>673,'R'=>485,'S'=>573,'T'=>584,'U'=>460,'V'=>546,'W'=>560,
	'X'=>521,'Y'=>360,'Z'=>594,'['=>355,'\\'=>447,']'=>404,'^'=>255,'_'=>388,'`'=>135,'a'=>480,'b'=>447,'c'=>515,'d'=>513,'e'=>360,'f'=>395,'g'=>304,'h'=>385,'i'=>185,'j'=>343,'k'=>283,'l'=>168,'m'=>521,
	'n'=>359,'o'=>358,'p'=>411,'q'=>349,'r'=>319,'s'=>350,'t'=>336,'u'=>390,'v'=>385,'w'=>477,'x'=>308,'y'=>277,'z'=>357,'{'=>204,'|'=>127,'}'=>196,'~'=>337,chr(127)=>500,chr(128)=>500,chr(129)=>500,chr(130)=>500,chr(131)=>500,
	chr(132)=>500,chr(133)=>500,chr(134)=>500,chr(135)=>500,chr(136)=>500,chr(137)=>500,chr(138)=>500,chr(139)=>500,chr(140)=>500,chr(141)=>500,chr(142)=>500,chr(143)=>500,chr(144)=>500,chr(145)=>500,chr(146)=>500,chr(147)=>500,chr(148)=>500,chr(149)=>500,chr(150)=>500,chr(151)=>500,chr(152)=>500,chr(153)=>500,
	chr(154)=>500,chr(155)=>500,chr(156)=>500,chr(157)=>500,chr(158)=>500,chr(159)=>500,chr(160)=>266,chr(161)=>390,chr(162)=>295,chr(163)=>387,chr(164)=>414,chr(165)=>452,chr(166)=>496,chr(167)=>435,chr(168)=>469,chr(169)=>519,chr(170)=>327,chr(171)=>377,chr(172)=>515,chr(173)=>412,chr(174)=>404,chr(175)=>408,
	chr(176)=>392,chr(177)=>505,chr(178)=>700,chr(179)=>558,chr(180)=>482,chr(181)=>499,chr(182)=>417,chr(183)=>479,chr(184)=>348,chr(185)=>417,chr(186)=>456,chr(187)=>413,chr(188)=>546,chr(189)=>507,chr(190)=>546,chr(191)=>510,chr(192)=>409,chr(193)=>520,chr(194)=>427,chr(195)=>288,chr(196)=>417,chr(197)=>433,
	chr(198)=>419,chr(199)=>458,chr(200)=>423,chr(201)=>533,chr(202)=>390,chr(203)=>429,chr(204)=>475,chr(205)=>397,chr(206)=>410,chr(207)=>414,chr(208)=>247,chr(209)=>0,chr(210)=>209,chr(211)=>249,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>98,chr(219)=>500,
	chr(220)=>500,chr(221)=>500,chr(222)=>500,chr(223)=>515,chr(224)=>198,chr(225)=>335,chr(226)=>241,chr(227)=>245,chr(228)=>264,chr(229)=>243,chr(230)=>353,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>30,chr(239)=>334,chr(240)=>473,chr(241)=>471,
	chr(242)=>485,chr(243)=>426,chr(244)=>542,chr(245)=>515,chr(246)=>505,chr(247)=>727,chr(248)=>618,chr(249)=>570,chr(250)=>486,chr(251)=>835,chr(252)=>500,chr(253)=>500,chr(254)=>500,chr(255)=>500);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='pletomw.z';
$size1=6083;
$size2=32450;
?>
