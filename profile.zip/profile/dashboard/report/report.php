<div class="row">
     <div class="col-lg-12">
             <h1 class="page-header"><i class="fa fa-pie-chart fa-fw"></i> รายงาน</h1>
     </div>        
</div>
<ol class="breadcrumb">
<li><a href="index.php"><?php echo @LA_MN_HOME;?></a></li>
  <li class="active">รายงาน</li>
</ol>

<div class="panel panel-yellow">
                        <div class="panel-heading">
                           การใช้งานระบบ
                        </div>
                        <div class="panel-body">
                           <a href="?p=report_logs" class="btn btn-default "><span class="text_white"><i class="fa fa-unlock-alt fa-fw fa-6x"></i><br/><br/>การเข้าใช้งานระบบ</span></a>
                        </div>
                      
                    </div>