<div class="row">
     <div class="col-lg-12">
             <h1 class="page-header"><i class="fa fa-puzzle-piece fa-fw"></i> [ผู้ดูแลระบบ] โมดูล</h1>
     </div>        
</div>
<ol class="breadcrumb">
   <li><a href="index.php">หน้าร้าน</a></li>
  <li><a href="?p=setting">ตั้งค่า</a></li>
  <li class="active">[ผู้ดูแลระบบ] โมดูล</li>
</ol>